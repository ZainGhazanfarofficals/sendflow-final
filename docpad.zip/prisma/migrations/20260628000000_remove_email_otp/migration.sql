-- DropTable
DROP TABLE "EmailOtp";
